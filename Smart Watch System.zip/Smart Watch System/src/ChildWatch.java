import java.io.*;
import java.net.*;

public class ChildWatch {

    public static void main(String[] args) throws Exception {

        Socket socket = new Socket("localhost", 5000);
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(
            new InputStreamReader(socket.getInputStream()));

        String id = "123";

        out.println("CHILD:" + id);

        String msg;
        while ((msg = in.readLine()) != null) {

            if (msg.equals("PARENT_ARRIVED")) {
                System.out.println("Child: Parent arrived!");

                Thread.sleep(2000);
                out.println("READY:" + id);
            }

            if (msg.equals("ALARM")) {
                System.out.println("CHILD ALARM!!!");
            }

            if (msg.equals("STOP")) {
                System.out.println("Child safe. Alarm stopped.");
            }
        }
    }
}