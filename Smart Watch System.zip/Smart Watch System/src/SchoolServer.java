import java.io.*;
import java.net.*;
import java.util.*;

public class SchoolServer {

    static Map<String, Socket> clients = new HashMap<>();

    public static void main(String[] args) throws Exception {
        ServerSocket server = new ServerSocket(5000);
        System.out.println("SERVER RUNNING...");

        while (true) {
            Socket socket = server.accept();
            new Thread(() -> handle(socket)).start();
        }
    }

    private static void handle(Socket socket) {
        try {
            BufferedReader in = new BufferedReader(
                new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(
                socket.getOutputStream(), true);

            String id = "";

            String msg;
            while ((msg = in.readLine()) != null) {

                if (msg.startsWith("PARENT:")) {
                    id = msg.split(":")[1];
                    clients.put("P:" + id, socket);
                    System.out.println("Parent connected: " + id);
                }

                if (msg.startsWith("CHILD:")) {
                    id = msg.split(":")[1];
                    clients.put("C:" + id, socket);
                    System.out.println("Child connected: " + id);
                }

                if (msg.startsWith("ARRIVED:")) {
                    id = msg.split(":")[1];
                    send("C:" + id, "PARENT_ARRIVED");
                }

                if (msg.startsWith("READY:")) {
                    id = msg.split(":")[1];
                    send("P:" + id, "START_TIMER");
                }

                if (msg.startsWith("CONFLICT:")) {
                    id = msg.split(":")[1];
                    send("P:" + id, "ALARM");
                    send("C:" + id, "ALARM");
                }

                if (msg.startsWith("OK:")) {
                    id = msg.split(":")[1];
                    send("P:" + id, "STOP");
                    send("C:" + id, "STOP");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void send(String key, String msg) {
        try {
            Socket s = clients.get(key);
            if (s != null) {
                PrintWriter out = new PrintWriter(s.getOutputStream(), true);
                out.println(msg);
            }
        } catch (Exception ignored) {}
    }
}