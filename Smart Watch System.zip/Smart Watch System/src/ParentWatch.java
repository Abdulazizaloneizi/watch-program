import java.io.*;
import java.net.*;

public class ParentWatch {

    public static void main(String[] args) throws Exception {

        Socket socket = new Socket("localhost", 5000);
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(
            new InputStreamReader(socket.getInputStream()));

        String id = "123";

        out.println("PARENT:" + id);

        // simulate arrival
        Thread.sleep(3000);
        System.out.println("Parent arrived at school");
        out.println("ARRIVED:" + id);

        String msg;
        while ((msg = in.readLine()) != null) {

            if (msg.equals("START_TIMER")) {
                System.out.println("Timer started (5 sec)");

                Thread.sleep(5000);

                boolean parentConfirms = false;

                if (!parentConfirms) {
                    out.println("CONFLICT:" + id);
                } else {
                    out.println("OK:" + id);
                }
            }

            if (msg.equals("ALARM")) {
                System.out.println("PARENT ALARM!!!");
            }

            if (msg.equals("STOP")) {
                System.out.println("Parent safe. Alarm stopped.");
            }
        }
    }
}